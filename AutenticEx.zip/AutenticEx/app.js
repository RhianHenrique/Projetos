// Incluindo o modulo('') Ldap.js
const ldap = require ('ldapjs')
// Incluindo o modulo('') Express.js
const express = require ('express');
// O modulo Express.js cria um objeto express(), no qual está sendo atribuido a variavel app
const app = express();

// Conexao 
app.listen('porta', function(){
    console.log('Sucess start');
})

// Metodo de autenticacao utilizando um nome de usuário e uma senha
function autenticacaoDN(username, senha){
    // Criacao do objeto client para comunicar com o servidor, abertura de um client
    const client = ldap.createClient({
        url: 'ldap://IP:PORTA'
    });
    // Bind, elementos necessários para a autenticacao
    client.bind('USERNAME', 'PASSWORD', function(err){
        if(err){
            console.log('Erro na conexao!')
        }else{
            console.log('Sucesso na conexao!');
        }
    })
}

autenticacaoDN('samaccountname = "a.b"', 'senha = "*****"');

// ---------------------------------------------------------------------------------------------------------

// Declarando a função
function autenticacao(){
    // Pegando os valores da entradas de usuario e senha 
    const user = document.getElementById('user').value;
    const password = document.getElementById('password').value;

// Criação de um objeto data que possui os valores obtidos da entrada 
    const data ={
        user: user,
        password: password
    }
    // Através da função fetch se cria um metodo post
    fetch('/ldap/authenticate', {// Caminho para lidar com LDAP
        method: POST,
        headers: {
            'Content-type': 'application/json', // Conteudo do cabeçalho possui dados em formato Json
        },
        body: JSON.stringify(data), // Transforma o objeto data em string Json
    })
    .then(data =>{
        alert('Autenticacao bem sucedida')
    })

    .catch(error =>{
        alert('Erro na autenticacao, verifique suas informações');
    });



}

